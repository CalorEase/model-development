# dataset > 2023-12-06 10:06pm
https://universe.roboflow.com/bangkit-feldj/dataset-9cro2

Provided by a Roboflow user
License: Public Domain

This dataset in a combination from 2 other dataset with a little modification on annotations. The dataset also contains another image to balance the class. 

First dataset (version 10):
***
@misc{ food-detection-yvcmw_dataset,
    title = { Food Detection Dataset },
    type = { Open Source Dataset },
    author = { FONA },
    howpublished = { \url{ https://universe.roboflow.com/fona/food-detection-yvcmw } },
    url = { https://universe.roboflow.com/fona/food-detection-yvcmw },
    journal = { Roboflow Universe },
    publisher = { Roboflow },
    year = { 2023 },
    month = { dec },
    note = { visited on 2023-12-04 },
}
***

second dataset (version 1):
***
@misc{ pendeteksi-makanan-khas_dataset,
    title = { pendeteksi makanan khas Dataset },
    type = { Open Source Dataset },
    author = { Fusion },
    howpublished = { \url{ https://universe.roboflow.com/fusion-qvvyj/pendeteksi-makanan-khas } },
    url = { https://universe.roboflow.com/fusion-qvvyj/pendeteksi-makanan-khas },
    journal = { Roboflow Universe },
    publisher = { Roboflow },
    year = { 2022 },
    month = { jun },
    note = { visited on 2023-12-04 },
}
***